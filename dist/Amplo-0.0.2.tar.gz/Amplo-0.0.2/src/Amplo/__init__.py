class Pipeline:
    def __init__(self):
        self.version = '0.0.1'